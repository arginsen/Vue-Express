export default function generate(color: string): string[];
