import { IconDefinition } from '../types';
declare const QqCircleFill: IconDefinition;
export default QqCircleFill;
