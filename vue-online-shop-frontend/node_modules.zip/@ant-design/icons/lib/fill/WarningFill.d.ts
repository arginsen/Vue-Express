import { IconDefinition } from '../types';
declare const WarningFill: IconDefinition;
export default WarningFill;
