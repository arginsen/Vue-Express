import { IconDefinition } from '../types';
declare const BackwardFill: IconDefinition;
export default BackwardFill;
