import { IconDefinition } from '../types';
declare const TrademarkCircleFill: IconDefinition;
export default TrademarkCircleFill;
