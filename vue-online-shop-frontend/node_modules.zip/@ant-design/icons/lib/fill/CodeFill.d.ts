import { IconDefinition } from '../types';
declare const CodeFill: IconDefinition;
export default CodeFill;
