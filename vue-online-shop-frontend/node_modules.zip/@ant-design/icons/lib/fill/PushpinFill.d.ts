import { IconDefinition } from '../types';
declare const PushpinFill: IconDefinition;
export default PushpinFill;
