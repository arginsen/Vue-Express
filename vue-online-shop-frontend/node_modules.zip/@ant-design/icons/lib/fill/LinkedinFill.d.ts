import { IconDefinition } from '../types';
declare const LinkedinFill: IconDefinition;
export default LinkedinFill;
