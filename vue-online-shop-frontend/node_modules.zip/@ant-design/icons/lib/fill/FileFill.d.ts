import { IconDefinition } from '../types';
declare const FileFill: IconDefinition;
export default FileFill;
