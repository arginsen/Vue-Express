import { IconDefinition } from '../types';
declare const RightCircleFill: IconDefinition;
export default RightCircleFill;
