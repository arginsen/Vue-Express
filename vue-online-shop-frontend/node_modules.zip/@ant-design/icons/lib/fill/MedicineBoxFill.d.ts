import { IconDefinition } from '../types';
declare const MedicineBoxFill: IconDefinition;
export default MedicineBoxFill;
