import { IconDefinition } from '../types';
declare const ApiFill: IconDefinition;
export default ApiFill;
