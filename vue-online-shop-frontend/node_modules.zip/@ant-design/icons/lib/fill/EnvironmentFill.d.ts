import { IconDefinition } from '../types';
declare const EnvironmentFill: IconDefinition;
export default EnvironmentFill;
