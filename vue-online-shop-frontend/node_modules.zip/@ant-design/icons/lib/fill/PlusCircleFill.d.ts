import { IconDefinition } from '../types';
declare const PlusCircleFill: IconDefinition;
export default PlusCircleFill;
