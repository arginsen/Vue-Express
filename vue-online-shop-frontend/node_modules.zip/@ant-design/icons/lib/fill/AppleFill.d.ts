import { IconDefinition } from '../types';
declare const AppleFill: IconDefinition;
export default AppleFill;
