import { IconDefinition } from '../types';
declare const LikeFill: IconDefinition;
export default LikeFill;
