import { IconDefinition } from '../types';
declare const AlipayCircleFill: IconDefinition;
export default AlipayCircleFill;
