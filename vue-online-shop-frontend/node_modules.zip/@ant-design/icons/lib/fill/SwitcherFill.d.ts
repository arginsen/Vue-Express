import { IconDefinition } from '../types';
declare const SwitcherFill: IconDefinition;
export default SwitcherFill;
