import { IconDefinition } from '../types';
declare const CalculatorFill: IconDefinition;
export default CalculatorFill;
