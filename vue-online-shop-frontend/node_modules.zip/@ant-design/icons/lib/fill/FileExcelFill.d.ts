import { IconDefinition } from '../types';
declare const FileExcelFill: IconDefinition;
export default FileExcelFill;
