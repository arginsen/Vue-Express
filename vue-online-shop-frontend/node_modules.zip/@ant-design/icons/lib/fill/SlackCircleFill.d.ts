import { IconDefinition } from '../types';
declare const SlackCircleFill: IconDefinition;
export default SlackCircleFill;
