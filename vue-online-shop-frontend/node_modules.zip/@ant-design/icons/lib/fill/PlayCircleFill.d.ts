import { IconDefinition } from '../types';
declare const PlayCircleFill: IconDefinition;
export default PlayCircleFill;
