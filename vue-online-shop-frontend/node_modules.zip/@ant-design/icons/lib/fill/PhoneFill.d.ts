import { IconDefinition } from '../types';
declare const PhoneFill: IconDefinition;
export default PhoneFill;
