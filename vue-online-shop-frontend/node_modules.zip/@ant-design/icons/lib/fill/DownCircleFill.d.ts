import { IconDefinition } from '../types';
declare const DownCircleFill: IconDefinition;
export default DownCircleFill;
