import { IconDefinition } from '../types';
declare const SketchSquareFill: IconDefinition;
export default SketchSquareFill;
