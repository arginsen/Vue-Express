import { IconDefinition } from '../types';
declare const CarFill: IconDefinition;
export default CarFill;
