import { IconDefinition } from '../types';
declare const CiCircleFill: IconDefinition;
export default CiCircleFill;
