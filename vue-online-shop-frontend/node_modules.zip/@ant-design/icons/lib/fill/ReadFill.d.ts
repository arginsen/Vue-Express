import { IconDefinition } from '../types';
declare const ReadFill: IconDefinition;
export default ReadFill;
