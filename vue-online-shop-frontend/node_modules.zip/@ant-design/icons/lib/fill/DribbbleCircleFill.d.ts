import { IconDefinition } from '../types';
declare const DribbbleCircleFill: IconDefinition;
export default DribbbleCircleFill;
