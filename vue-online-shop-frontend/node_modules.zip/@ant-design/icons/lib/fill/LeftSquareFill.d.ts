import { IconDefinition } from '../types';
declare const LeftSquareFill: IconDefinition;
export default LeftSquareFill;
