import { IconDefinition } from '../types';
declare const AndroidOutline: IconDefinition;
export default AndroidOutline;
