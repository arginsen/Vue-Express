import { IconDefinition } from '../types';
declare const BehanceSquareOutline: IconDefinition;
export default BehanceSquareOutline;
