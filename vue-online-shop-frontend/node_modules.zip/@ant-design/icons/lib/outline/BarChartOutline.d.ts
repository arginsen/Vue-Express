import { IconDefinition } from '../types';
declare const BarChartOutline: IconDefinition;
export default BarChartOutline;
