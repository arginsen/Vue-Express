import { IconDefinition } from '../types';
declare const ArrowDownOutline: IconDefinition;
export default ArrowDownOutline;
