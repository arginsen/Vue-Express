import { IconDefinition } from '../types';
declare const BarsOutline: IconDefinition;
export default BarsOutline;
