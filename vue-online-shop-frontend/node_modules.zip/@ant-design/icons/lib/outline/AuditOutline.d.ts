import { IconDefinition } from '../types';
declare const AuditOutline: IconDefinition;
export default AuditOutline;
