import { IconDefinition } from '../types';
declare const AlibabaOutline: IconDefinition;
export default AlibabaOutline;
