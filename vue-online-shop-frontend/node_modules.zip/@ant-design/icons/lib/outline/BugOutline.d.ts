import { IconDefinition } from '../types';
declare const BugOutline: IconDefinition;
export default BugOutline;
