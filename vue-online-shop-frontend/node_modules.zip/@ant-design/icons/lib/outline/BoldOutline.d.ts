import { IconDefinition } from '../types';
declare const BoldOutline: IconDefinition;
export default BoldOutline;
