import { IconDefinition } from '../types';
declare const AlignRightOutline: IconDefinition;
export default AlignRightOutline;
