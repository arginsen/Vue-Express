import { IconDefinition } from '../types';
declare const AlipayOutline: IconDefinition;
export default AlipayOutline;
