import { IconDefinition } from '../types';
declare const AreaChartOutline: IconDefinition;
export default AreaChartOutline;
