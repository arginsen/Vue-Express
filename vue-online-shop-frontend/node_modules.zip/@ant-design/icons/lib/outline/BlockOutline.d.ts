import { IconDefinition } from '../types';
declare const BlockOutline: IconDefinition;
export default BlockOutline;
